#include <iostream>
#include <string>
using namespace std;

struct node {
    int l;
    int r;
    int value;
    node(int l, int r, int v){
        this->l = l;
        this->r = r;
        this->value = v;
    }
    node (){}
};

struct subarray {
    node s_l;
    node s_r;
    node t;
    node max;
    subarray(node l, node r, node t, node max){
        this->s_l = l;
        this->s_r = r;
        this->t = t;
        this->max = max;
    }
    subarray(){}
};


subarray DivideAndConquer(int* Array, int left, int right)
{

    if(right == left){
        node n (left, right, Array[left]);
        return subarray(n, n, n, n);
    }
    int middle = (left+right)/2;
    subarray sub_left = DivideAndConquer(Array, left, middle);
    subarray sub_right = DivideAndConquer(Array, middle+1, right);

    subarray cur;
    if (sub_left.t.value + sub_right.s_l.value > sub_left.s_l.value){
        cur.s_l.value = sub_left.t.value + sub_right.s_l.value;
        cur.s_l.r = sub_right.s_l.r;
        cur.s_l.l = sub_left.s_l.l;
    } else {
        cur.s_l = sub_left.s_l;
    }

    if (sub_right.t.value + sub_left.s_r.value > sub_right.s_r.value){
        cur.s_r.value = sub_right.t.value + sub_left.s_r.value;
        cur.s_r.l = sub_left.s_r.l;
        cur.s_r.r = sub_right.s_r.r;
    } else {
        cur.s_r = sub_right.s_r;
    }

    cur.t.value = sub_left.t.value + sub_right.t.value;
    cur.t.l = sub_left.t.l;
    cur.t.r = sub_right.t.r;

    if (cur.s_l.value >= cur.s_r.value &&
         cur.s_l.value >= cur.t.value &&
         cur.s_l.value >= sub_left.max.value &&
         cur.s_l.value >= sub_right.max.value){
        cur.max = cur.s_l;
    } else if (cur.s_r.value >= cur.s_l.value &&
         cur.s_r.value >= cur.t.value &&
         cur.s_r.value >= sub_left.max.value &&
         cur.s_r.value >= sub_right.max.value){
        cur.max = cur.s_r;
    } else if (sub_left.max.value >= cur.s_l.value &&
         sub_left.max.value >= cur.t.value &&
         sub_left.max.value >= cur.s_r.value &&
         sub_left.max.value >= sub_right.max.value ){
        cur.max = sub_left.max;
    } else {
        cur.max = sub_right.max;
    }

    if (sub_left.s_r.value + sub_right.s_l.value > cur.max.value){
        cur.max.value = sub_left.s_r.value + sub_right.s_l.value;
        cur.max.l = sub_left.s_r.l;
        cur.max.r = sub_right.s_l.r;
    }
    return cur;
}

int main()
{
    const int ArraySize = 16;
    string DateAndPricesArray[ArraySize][2] = {{"01.05.2020", "150"}, {"02.05.2020", "149"}, {"03.05.2020", "138"}, {"04.05.2020", "146"},
                                               {"05.05.2020", "121"}, {"06.05.2020", "121"}, {"07.05.2020", "144"}, {"08.05.2020", "147"},
                                               {"09.05.2020", "158"}, {"10.05.2020", "150"}, {"11.05.2020", "155"}, {"12.05.2020", "149"},
                                               {"13.05.2020", "166"}, {"14.05.2020", "122"}, {"15.05.2020", "121"}, {"16.05.2020", "130"}};

    int PriceChangeArray[ArraySize-1];
    for (int i=0; i<ArraySize-1; i++) {
        PriceChangeArray[i] = atoi(DateAndPricesArray[i+1][1].c_str()) - atoi(DateAndPricesArray[i][1].c_str());
    }

    subarray FinalResult = DivideAndConquer(PriceChangeArray, 0, ArraySize-2);
    if(FinalResult.max.value > 0) cout << "Stonks value: " << FinalResult.max.value << endl;
    else cout << "Best of nonstonks value: " << FinalResult.max.value << endl;
    cout << "It only stonks like this if you buy on " << DateAndPricesArray[FinalResult.max.l][0] << " and then sell on " << DateAndPricesArray[FinalResult.max.r+1][0] << "!!!" << endl;

  //dear teacher, i use unix so i don't need it, if you use windows or other operating system please uncomment the string below
  //system("pause");
    return 0;
}
