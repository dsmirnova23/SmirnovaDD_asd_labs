#include <iostream>
using namespace std;

/*У Вас есть калькулятор с темя кнопками:

Прибавить к текущему числу 1
Домножить текущее число на 2
Домножить текущее число на 3
Найти такую минимальную последовательность нажатия кнопок на калькуляторе, позволяющую получить введённое пользователем число N, если в начальный момент текущее число 0.*/

string FindMinSequence (int num){
    string s;
    int P[num+1];
    int A[num+1];
    A[0]=0;
    int prev=0;
    for (int i=1; i<num+1; i++) {
        A[i] = A[i-1];
        prev = i-1;
        if (i%2==0 && A[i/2]<A[i]){
            A[i] = A[i/2];
            prev = i/2;
        }
        if (i%3==0 && A[i/3]<A[i]){
            A[i] = A[i/3];
            prev = i/3;
        }
        P[i]=prev;
        A[i]+=1;
    }
    int j=num;
    while(j!=0){
        if(j%3==0 && j/prev==3) s.insert(0,"3 ");
        else if(j%2==0 && j/prev==2) s.insert(0,"2 ");
        else s.insert(0,"1 ");
        j=prev;
        prev=P[prev];
    }
    return s;
}

int main()
{
    int N=0;
    cout << "Please enter a positive integer" << endl;
    while(N<=0){
        cin >> N;
        if(N<=0) cout << "Incorrect value. Please try again" << endl;
    }

    string minseq = FindMinSequence (N);
    cout << "Minimal sequence of calculator actions to get from 0 to " << N << " is " << minseq << endl;

    //dear teacher, i use unix so i don't need it, if you use windows or other operating system please uncomment the string below
    //system("pause");
    return 0;
}
