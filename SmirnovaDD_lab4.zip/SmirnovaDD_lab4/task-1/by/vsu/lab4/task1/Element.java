package by.vsu.lab4.task1;

public class Element {
	
	private int key;
	
	public Element(int value) { 
        this.key = value; 
    }
	
	public Element() {} 
 
    public String toString() { 
        return "{" + key + "}"; 
    } 
 
    public int getKey() { 
        return key; 
    }
    
    public void setKey(int value) { 
        this.key = value; 
    }
    
}
