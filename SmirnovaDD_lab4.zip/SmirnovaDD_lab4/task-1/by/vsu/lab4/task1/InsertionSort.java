package by.vsu.lab4.task1;

public class InsertionSort {

	public static int[] sort(Element[] Array) {
		int comp = 0;
		int swap = 0;
		int[] counter = new int[2];
		
		Element x;
		int l, r, mid;
		
		for(int i = 1; i < Array.length; i++) {
			x = Array[i];
			l = 0;
			r = i;
			while(l < r) {
				mid = (l+r)/2;
				if(Array[mid].getKey() < x.getKey()) {
					l = mid+1;
				}
				else {
					r = mid;
				}
				comp+=2;
			}
			for(int j = i; j >= r+1; j--) {
				Array[j] = Array[j-1];
				swap++;
				comp++;
			}
			Array[r] = x;
			swap++;
			comp++;
		}

		counter[0] = comp;
		counter[1] = swap;
		
		return counter;
	}
}
