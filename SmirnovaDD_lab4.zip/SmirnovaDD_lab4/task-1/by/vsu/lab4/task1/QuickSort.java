package by.vsu.lab4.task1;

public class QuickSort {

	public static int[] sort(Element[] Array, int L, int R) {
		int comp = 0;
		int swap = 0;
		int[] counter = new int[2];
		int[] tmp = new int[2];
		
		Element x = Array[(L+R)/2];
		Element buf;
		int i = L;
		int j = R;
		
		do {
			while(Array[i].getKey() < x.getKey()) {
				i++;
				comp++;
			}
			while(Array[j].getKey() > x.getKey()) {
				j--;
				comp++;
			}
			if(i<=j) {
				buf = Array[i];
				Array[i] = Array[j];
				Array[j] = buf;
				i++;
				j--;
				swap++;
				comp++;				
			}
			comp++;
		} while(i < j);
		
		if (L < j) {
			tmp = QuickSort.sort(Array, L, j);
			comp+=tmp[0];
			swap+=tmp[1];
			comp++;
		}
		if (i < R) {
			tmp = QuickSort.sort(Array, i, R);
			comp+=tmp[0];
			swap+=tmp[1];
			comp++;
		}
		
		counter[0] = comp;
		counter[1] = swap;
		
		return counter;
	}
}
