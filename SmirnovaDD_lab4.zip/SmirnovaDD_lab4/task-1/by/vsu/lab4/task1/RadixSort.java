package by.vsu.lab4.task1;

import java.util.Arrays;

public class RadixSort {

	static int comp;
	static int swap;
	static int[] counter = new int[2];

	static int getMax(Element arr[], int n) 
    { 
        int mx = arr[0].getKey(); 
        for (int i = 1; i < n; i++) {
            if (arr[i].getKey() > mx) {
                mx = arr[i].getKey();
                comp++;
            }
            comp++;
        }
        return mx; 
    } 
  
    static void countSort(Element arr[], int n, int exp) 
    { 
        int output[] = new int[n]; 
        int i; 
        int count[] = new int[10]; 
        Arrays.fill(count,0); 
  
        for (i = 0; i < n; i++) {
            count[ (arr[i].getKey()/exp)%10 ]++;
            comp++;
        }
  
        for (i = 1; i < 10; i++) {
            count[i] += count[i - 1]; 
            swap++;
        }
  
        for (i = n - 1; i >= 0; i--) 
        { 
            output[count[ (arr[i].getKey()/exp)%10 ] - 1] = arr[i].getKey(); 
            count[ (arr[i].getKey()/exp)%10 ]--; 
        } 
  
        for (i = 0; i < n; i++) 
            arr[i].setKey(output[i]); 
    } 
  
    static int[] sort(Element arr[], int n) 
    { 
        int m = getMax(arr, n); 
  
        for (int exp = 1; m/exp > 0; exp *= 10) 
            countSort(arr, n, exp); 

		counter[0] = comp;
		counter[1] = swap;
		
		return counter;
    } 
}
