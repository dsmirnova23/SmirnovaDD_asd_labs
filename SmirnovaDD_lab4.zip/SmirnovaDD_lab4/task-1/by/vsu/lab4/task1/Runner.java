package by.vsu.lab4.task1;

import java.util.Arrays;

/*Реализовать 5 алгоритмов сортировок:

1. сортировка выбором
2. сортировка вставками
3. сортировка обменом
4. быстрая сортировка
5. поразрядная сортировка*/

public class Runner {

	public static void main(String[] args) {
		int array_size = 10;
		Element[] arr = new Element[array_size];
		int[] counter = new int[2];
		
		//sorted array
		/*for(int i = 0; i < array_size; i++) {
			arr[i] = new Element(i);
		}*/
		
		//back-sorted array
		/*for(int i = 0; i < array_size; i++) {
			arr[i] = new Element(array_size-i);
		}*/
		
		//randomizes
		int max = 100;
		for(int i = 0; i < array_size; i++) {
			arr[i] = new Element((int)(Math.random() * ++max));
		}
		Element[] arr2 = Arrays.copyOf(arr, array_size);
		Element[] arr3 = Arrays.copyOf(arr, array_size);
		Element[] arr4 = Arrays.copyOf(arr, array_size);
		Element[] arr5 = Arrays.copyOf(arr, array_size);
		
		System.out.println("Unsorted array:");
		System.out.println(Arrays.deepToString(arr));
		System.out.println("");
		
		long start = System.currentTimeMillis();
		counter = SelectionSort.sort(arr);
		long finish = System.currentTimeMillis();
		long timeConsumedMillis = finish - start;
		
		System.out.println("Sorted array (selection sort):");
		System.out.println(Arrays.deepToString(arr));
		System.out.print("Compare:");
		System.out.println(counter[0]);
		System.out.print("Swap:");
		System.out.println(counter[1]);
		System.out.print("Time:");
		System.out.print(timeConsumedMillis);
		System.out.println(" ms");
		System.out.println("");
		
		start = System.currentTimeMillis();
		counter = InsertionSort.sort(arr2);
		finish = System.currentTimeMillis();
		timeConsumedMillis = finish - start;
		
		System.out.println("Sorted array (binary insertion sort):");
		System.out.println(Arrays.deepToString(arr2));
		System.out.print("Compare:");
		System.out.println(counter[0]);
		System.out.print("Swap:");
		System.out.println(counter[1]);
		System.out.print("Time:");
		System.out.print(timeConsumedMillis);
		System.out.println(" ms");
		System.out.println("");
		
		start = System.currentTimeMillis();
		counter = ShakerSort.sort(arr3);
		finish = System.currentTimeMillis();
		timeConsumedMillis = finish - start;
		
		System.out.println("Sorted array (shaker sort):");
		System.out.println(Arrays.deepToString(arr3));
		System.out.print("Compare:");
		System.out.println(counter[0]);
		System.out.print("Swap:");
		System.out.println(counter[1]);
		System.out.print("Time:");
		System.out.print(timeConsumedMillis);
		System.out.println(" ms");
		System.out.println("");
		
		start = System.currentTimeMillis();
		counter = QuickSort.sort(arr4, 0, array_size-1);
		finish = System.currentTimeMillis();
		timeConsumedMillis = finish - start;
		
		System.out.println("Sorted array (quick sort):");
		System.out.println(Arrays.deepToString(arr4));
		System.out.print("Compare:");
		System.out.println(counter[0]);
		System.out.print("Swap:");
		System.out.println(counter[1]);
		System.out.print("Time:");
		System.out.print(timeConsumedMillis);
		System.out.println(" ms");
		System.out.println("");
		
		start = System.currentTimeMillis();
		counter = RadixSort.sort(arr5, array_size);
		finish = System.currentTimeMillis();
		timeConsumedMillis = finish - start;
		
		System.out.println("Sorted array (radix sort):");
		System.out.println(Arrays.deepToString(arr5));
		System.out.print("Compare:");
		System.out.println(counter[0]);
		System.out.print("Swap:");
		System.out.println(counter[1]);
		System.out.print("Time:");
		System.out.print(timeConsumedMillis);
		System.out.println(" ms");
		System.out.println("");
	}

}
