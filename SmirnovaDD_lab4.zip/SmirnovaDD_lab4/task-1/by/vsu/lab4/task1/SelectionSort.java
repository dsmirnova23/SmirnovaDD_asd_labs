package by.vsu.lab4.task1;

public class SelectionSort {
	
	public static int[] sort(Element[] Array) {
		int comp = 0;
		int swap = 0;
		int[] counter = new int[2];
		
		int k;
		Element buf;
		
		for(int i = 0; i < Array.length-1; i++) {
			k = i;
			for(int j = i+1; j < Array.length; j++) {
				if(Array[j].getKey() < Array[k].getKey()) {
					k = j;
					comp++;
				}
				comp++;
			}
			buf = Array[i];
			Array[i] = Array[k];
			Array[k] = buf;
			swap++;
			comp++;
		}

		counter[0] = comp;
		counter[1] = swap;
		
		return counter;
	}
}
