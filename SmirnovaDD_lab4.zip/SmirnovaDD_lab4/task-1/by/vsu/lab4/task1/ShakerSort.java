package by.vsu.lab4.task1;

public class ShakerSort {

	public static int[] sort(Element[] Array) {
		int comp = 0;
		int swap = 0;
		int[] counter = new int[2];
		
		Element buf;
		int l = 1;
		int r = Array.length-1;
		int k = Array.length-1;
		
		do {
			for(int j = r; j >= l; j--) {
				if(Array[j-1].getKey() > Array[j].getKey()) {
					buf = Array[j-1];
					Array[j-1] = Array[j];
					Array[j] = buf;
					k = j;
					comp++;
					swap++;
				}
				comp++;
			}
			l = k+1;
			for(int j = l; j <= r; j++) {
				if(Array[j-1].getKey() > Array[j].getKey()) {
					buf = Array[j-1];
					Array[j-1] = Array[j];
					Array[j] = buf;
					k = j;
					comp++;
					swap++;
				}
				comp++;
			}
			r = k-1;
			comp++;
		} while(l<=r);
		
		counter[0] = comp;
		counter[1] = swap;
		
		return counter;
	}
}
